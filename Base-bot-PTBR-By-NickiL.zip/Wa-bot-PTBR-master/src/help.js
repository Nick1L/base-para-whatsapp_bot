const help = (prefix) => {
	return `
❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌
❌     🔵ESTA BASE FOI CRIADA POR MHANKBARBAR 🔵     
❌     🔴E TOTALMENTE TRADUZIDA POR SKILLER 🔴           
❌     🔵QUANDO USA-LA SEMPRE DEIXAR OS CRÉDITOS 🔵
❌     💎  © *Copyright © by SkillerOfc-Mhankbarbar*              
❌     💎  Youtube = https://youtube.com/c/SkillerOfc             
❌     💎  contatos = wa.me/558892594715                
❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌
	
PARA FIGURINHAS
comando : *${prefix}sticker* or *${prefix}stiker*
desc: converter imagem / gif / vídeo em adesivo
uso: responder imagem / gif / vídeo ou enviar imagem / gif / vídeo com legenda \n
comando : *${prefix}toimg*
desc: converter adesivo em imagem
uso: adesivo de resposta \n

PARA GRUPOS

comando : *${prefix}bemvindo [1/0]*
desc: boas vindas 
uso: * ${prefix}bemvindo 1 ou 0* \n
comando : *${prefix}add*
desc: adicionar membro ao grupo
uso: * ${prefix} add 62813xxxxx * \n
observação: só pode ser usado quando o bot se torna admin e quem envia o comando é admin! \n
comando : *${prefix}kick*
desc: expulsar membros do grupo
uso: * ${prefix} kick @ tagmember * \n
observação: só pode ser usado quando o bot se torna admin e quem envia o comando é admin! \n
comando : *${prefix}promote*
desc: tornar o membro do grupo como administrador do grupo
observação: só pode ser usado quando o bot se torna admin e quem envia o comando é admin! \n
uso: * ${prefix} promova @ tagmember * \n
observação: só pode ser usado quando o bot se torna admin e quem envia o comando é admin! \ n
comando : *${prefix}demote*
desc: tornar o administrador do grupo como membro do grupo
uso: * ${prefix}demote @membro * \n
observação: só pode ser usado quando o bot se torna admin e quem envia o comando é admin! \n
comando : *${prefix}linkgroup*
desc: pegue o link do grupo
uso: basta enviar o comando
comando : *${prefix}leave*
desc: Faça o bot sair do grupo
uso: basta enviar o comando
nota: só pode ser usado por administradores de grupo e proprietário do bot\n
comando : *${prefix}marcar*
desc: marca todos os membros do grupo, incluindo administradores também
uso: basta enviar o comando
nota: este comando pode ser usado se você for um administrador de grupo
comando : *${prefix}marcar2*
desc: marca todos os membros do grupo, incluindo administradores também
uso: basta enviar o comando
nota: este comando pode ser usado se você for um administrador de grupo
comando : *${prefix}marcar3*
desc: marca todos os membros do grupo, incluindo administradores também
uso: basta enviar o comando
nota: este comando pode ser usado se você for um administrador de grupo

PARA DONO
comando : *${prefix}bc*
desc: transmissão
uso: *${prefix}bc [texto] * \nexemplo: *${prefix}bc sua mensagem*
nota: este comando só pode ser usado pelo proprietário do bot \n
comando : *${prefix}setprefix*
desc: substituir prefixo
uso: *${prefix} setprefix [texto | opcional] * \ nexemplo: * $ {prefix}setprefix ?*
nota: este comando só pode ser usado pelo proprietário do bot \n\n

❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌
❌     🔵ESTA BASE FOI CRIADA POR MHANKBARBAR 🔵     
❌     🔴E TOTALMENTE TRADUZIDA POR SKILLER 🔴           
❌     🔵QUANDO USA-LA SEMPRE DEIXAR OS CRÉDITOS 🔵
❌     💎  © *Copyright © by SkillerOfc-Mhankbarbar*              
❌     💎  Youtube = https://youtube.com/c/SkillerOfc             
❌     💎  contatos = wa.me/558892594715                
❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌
	

`
}

exports.help = help
